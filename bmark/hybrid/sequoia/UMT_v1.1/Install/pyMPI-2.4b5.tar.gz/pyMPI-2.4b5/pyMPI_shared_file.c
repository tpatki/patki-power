/**************************************************************************/
/* FILE   **************    pyMPI_shared_file.c    ************************/
/**************************************************************************/
/* Author: Patrick Miller April 22 2003                                   */
/* Copyright (C) 2003 University of California Regents                    */
/**************************************************************************/
/* Should eventually reflect ROMIO interface to files                     */
/**************************************************************************/
#include "mpi.h"
#undef _POSIX_C_SOURCE
#include "Python.h"
#include "pyMPI.h"
#include "pyMPI_Macros.h"

START_CPLUSPLUS

END_CPLUSPLUS

import simple
print simple.foom

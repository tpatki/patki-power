import example
print example.fact(5)
print example.my_mod(7,3)
print example.get_time()

/**************************************************************************/
/* FILE   **************        pyMPI_site.c       ************************/
/**************************************************************************/
/* Author: Patrick Miller April 29 2003                                   */
/* Copyright (C) 2003 University of California Regents                    */
/**************************************************************************/
/* Replacement for site module (to run ours instead)                      */
/**************************************************************************/

#include "mpi.h"
#undef _POSIX_C_SOURCE
#include "Python.h"
#include "pyMPI.h"
#include "pyMPI_Macros.h"

/**************************************************************************/
/* GLOBAL **************         pyMPI_site        ************************/
/**************************************************************************/
/* Load the site module.  This normally happens in Py_Initialize() where  */
/* it loads the site.py in $PREFIX/lib/pythonX.X/site.py.  We do the same */
/* but we also force a load of the MPI module.                            */
/**************************************************************************/
void pyMPI_site(void) {
  PyObject* imp = 0;
  PyObject* site = 0;
  PyObject* ignore= 0;
  PyObject* mpi = 0;
  PyObject* sys_path = 0;
  int sys_path_length;
  int old_sys_path_length;
  PyObject* new_directories = 0;
  int number_of_new_directories = 0;
  char* user_directory = 0;

#ifdef PYMPI_PYTHON_SITE_PY
  /* ----------------------------------------------- */
  /* We need to import site.py as a file             */
  /* ----------------------------------------------- */
  PYCHECK( imp/*owned*/ = PyImport_ImportModule("imp") );


  /* ----------------------------------------------- */
  /* One of the side effects of site.py is to add in */
  /* the site directories and all the .pth files     */
  /* We get before and after snapshots of sys.path   */
  /* ----------------------------------------------- */
  PYCHECK( sys_path/*borrow*/ = PySys_GetObject("path") );
  PYCHECK( old_sys_path_length = PyObject_Size(sys_path) );
  PYCHECK( site/*owned*/ =
           PyObject_CallMethod(imp,"load_source","ss",
                               "site",
                               PYMPI_PYTHON_SITE_PY) );
  PYCHECK( sys_path/*borrow*/ = PySys_GetObject("path") );
  Assert(PyList_Check(sys_path));
  PYCHECK( sys_path_length = PyObject_Size(sys_path) );


  /* ----------------------------------------------- */
  /* The new directories are at the end of the path  */
  /* We get that slice and then delete it from the   */
  /* path (we add it back in below).  This way we    */
  /* can insert the pyMPI directories in front of    */
  /* the python site directories and .pth dirs.      */
  /* ----------------------------------------------- */
  PYCHECK( new_directories = PyList_GetSlice(sys_path,old_sys_path_length,sys_path_length) );
  PYCHECK( number_of_new_directories = PyObject_Size(new_directories) );
  PYCHECK( PyList_SetSlice(sys_path,old_sys_path_length,sys_path_length,0) );

  /* ----------------------------------------------- */
  /* If the extender provides a directory, add it in */
  /* here.                                           */
  /* ----------------------------------------------- */
  user_directory/*borrow*/ = pyMPI_user_directory();
  if ( user_directory ) {
    PYCHECK( ignore/*owned*/ =
             PyObject_CallMethod(site,
                                 "addsitedir",
                                 "s", 
                                 user_directory) );
    Py_DECREF(ignore);
    ignore = 0;
  }

  /* ----------------------------------------------- */
  /* Similarly, we add in the pyMPI site packages    */
  /* ----------------------------------------------- */
  PYCHECK( ignore/*owned*/ = 
           PyObject_CallMethod(
                               site,
                               "addsitedir",
                               "s",
                               PYMPI_SITEDIR) );
  Py_DECREF(ignore);
  ignore = 0;

  /* ----------------------------------------------- */
  /* Stick the saved directories back into the path  */
  /* ----------------------------------------------- */
  PYCHECK( sys_path/*borrow*/ = PySys_GetObject("path") );
  PYCHECK( sys_path_length = PyObject_Size(sys_path) );
  PYCHECK( PyList_SetSlice(sys_path,
                           sys_path_length,
                           sys_path_length+number_of_new_directories,
                           new_directories) );

#endif 

  /* ----------------------------------------------- */
  /* Handle initialization                           */
  /* ----------------------------------------------- */
  PYCHECK( mpi = PyImport_ImportModule("mpi") );


  /* Fall through */
 pythonError:
  Py_XDECREF(imp);
  Py_XDECREF(site);
  Py_XDECREF(ignore);
  Py_XDECREF(mpi);
  return;
}
